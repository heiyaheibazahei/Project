#ifndef MENUBUTTON_H
#define MENUBUTTON_H

#include<QPushButton>
class MenuButton
{
public:
    MenuButton();

    //创建按钮
    QPushButton *btn;

    int button_width;
    int button_height;

};

#endif // MENUBUTTON_H
